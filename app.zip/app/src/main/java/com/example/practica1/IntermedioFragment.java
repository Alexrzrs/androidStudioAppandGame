package com.example.practica1;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.practica1.databinding.FragmentFacilBinding;
import com.example.practica1.databinding.FragmentIntermedioBinding;
import com.example.practica1.databinding.FragmentJuegoBinding;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class IntermedioFragment extends Fragment {

    private FragmentIntermedioBinding binding;

    private Timer timer;
    private int timeCounter=90;
    private int Adivina;
    private int vidas = 7;
    private int score = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentIntermedioBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Adivina = new Random().nextInt(41); //Número aleatorio del 0 al 50

        Toast.makeText(
                getActivity(),
                "Número a adivinar:" + Adivina,
                Toast.LENGTH_LONG
        ).show();

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        binding.textViewTiempo.setText(String.valueOf(timeCounter));
                        timeCounter--;

                        if (timeCounter == -1){
                            timer.cancel();
                            binding.textViewPista.setText("SE TE ACABO EL TIEMPO");
                            binding.buttonSalir.setVisibility(View.VISIBLE);
                            binding.buttonOtra.setVisibility(View.VISIBLE);
                            binding.etNumero.setVisibility(View.INVISIBLE);
                            binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                        }
                    }
                });
            }
        }, 1000, 1000);




        binding.buttonSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(IntermedioFragment.this)
                        .navigate(R.id.action_IntermedioFragment_to_MenuFragment);

                Toast.makeText(
                        getActivity(),
                        "Tu Score fue de:" + score,
                        Toast.LENGTH_LONG
                ).show();
            }
        });



        binding.buttonAdivinar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int numero = Integer.parseInt(binding.etNumero.getText().toString());

                if (numero == Adivina) {
                    binding.textViewPista.setText("GANASTE");
                    timer.cancel();
                    binding.etNumero.setVisibility(View.INVISIBLE);
                    binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                    binding.buttonSalir.setVisibility(View.VISIBLE);
                    binding.buttonOtra.setVisibility(View.VISIBLE);
                    score += 10;
                }

                else if (numero > Adivina) {
                    binding.textViewPista.setText("TU NÚMERO ES MAYOR");
                    vidas--;
                    mostrarVidas();
                }

                else if (numero < Adivina) {
                    binding.textViewPista.setText("TU NÚMERO ES MENOR");

                    vidas--;
                    mostrarVidas();
                }

                if (vidas == 0){
                    timer.cancel();
                    binding.textViewPista.setText("PERDISTE");
                    binding.etNumero.setVisibility(View.INVISIBLE);
                    binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                    binding.buttonSalir.setVisibility(View.VISIBLE);
                    binding.buttonOtra.setVisibility(View.VISIBLE);
                }
            }
        });

        //Crea nueva partida

        binding.buttonOtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timeCounter=90;
                vidas = 7;
                Adivina = new Random().nextInt(41); //Número aleatorio del 0 al 50


                Toast.makeText(
                        getActivity(),
                        "Número a adivinar:" + Adivina,
                        Toast.LENGTH_LONG
                ).show();
                binding.etNumero.setVisibility(View.VISIBLE);
                binding.buttonAdivinar.setVisibility(View.VISIBLE);
                binding.buttonSalir.setVisibility(View.INVISIBLE);
                binding.buttonOtra.setVisibility(View.INVISIBLE);
                binding.textViewVidas.setText("♥♥♥♥♥♥♥");
                binding.textViewTiempo.setText("90");
                binding.textViewPista.setText("Comienza a Adivinar");
                binding.etNumero.setText("");
                timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                binding.textViewTiempo.setText(String.valueOf(timeCounter));
                                timeCounter--;

                                if (timeCounter == -1){
                                    timer.cancel();
                                    binding.textViewPista.setText("SE TE ACABO EL TIEMPO");
                                    binding.buttonSalir.setVisibility(View.VISIBLE);
                                    binding.buttonOtra.setVisibility(View.VISIBLE);
                                    binding.etNumero.setVisibility(View.INVISIBLE);
                                    binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                                }
                            }
                        });
                    }
                }, 1000, 1000);

                binding.buttonAdivinar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final int numero = Integer.parseInt(binding.etNumero.getText().toString());

                        if (numero == Adivina) {
                            binding.textViewPista.setText("GANASTE");
                            timer.cancel();
                            binding.etNumero.setVisibility(View.INVISIBLE);
                            binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                            binding.buttonSalir.setVisibility(View.VISIBLE);
                            binding.buttonOtra.setVisibility(View.VISIBLE);
                            score += 10;

                        }

                        else if (numero > Adivina) {
                            binding.textViewPista.setText("TU NÚMERO ES MAYOR");
                            vidas--;
                            mostrarVidas();
                        }

                        else if (numero < Adivina) {
                            binding.textViewPista.setText("TU NÚMERO ES MENOR");

                            vidas--;
                            mostrarVidas();
                        }

                        if (vidas == 0){
                            timer.cancel();
                            binding.textViewPista.setText("PERDISTE");
                            binding.etNumero.setVisibility(View.INVISIBLE);
                            binding.buttonAdivinar.setVisibility(View.INVISIBLE);
                            binding.buttonSalir.setVisibility(View.VISIBLE);
                            binding.buttonOtra.setVisibility(View.VISIBLE);
                        }
                    }
                });

            }
        });

        return root;
    }

    private void mostrarVidas() {
        binding.textViewVidas.setText("");
        for (int i = 0; i < vidas; i++) {
            binding.textViewVidas.setText(binding.textViewVidas.getText() + "♥");
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        timer.cancel();
        binding = null;
    }


}