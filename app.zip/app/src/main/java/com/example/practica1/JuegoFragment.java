package com.example.practica1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.practica1.databinding.FragmentJuegoBinding;
import com.example.practica1.databinding.FragmentMenuBinding;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class JuegoFragment extends Fragment {

    private FragmentJuegoBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentJuegoBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonFacil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(JuegoFragment.this)
                        .navigate(R.id.action_JuegoFragment_to_FacilFragment);
            }
        });

        binding.buttonIntermedio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(JuegoFragment.this)
                        .navigate(R.id.action_JuegoFragment_to_IntermedioFragment);
            }
        });

        binding.buttonDificl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(JuegoFragment.this)
                        .navigate(R.id.action_JuegoFragment_to_EpicoFragment);
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}