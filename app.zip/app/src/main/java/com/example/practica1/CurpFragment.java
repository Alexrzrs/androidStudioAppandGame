package com.example.practica1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.practica1.databinding.FragmentCurpBinding;
import com.example.practica1.databinding.FragmentFirstBinding;

import java.util.Locale;
import java.util.Random;

public class CurpFragment extends Fragment {

    private FragmentCurpBinding binding;
    private String vocales = "AEIOUaeiou";
    private String nomvoc;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentCurpBinding.inflate(inflater, container, false);

        binding.buttonLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.etNombres.setText("");
                binding.etApat.setText("");
                binding.etAmat.setText("");
                binding.etAno.setText("");
                binding.spDia.setSelection(0,true);
                binding.spMes.setSelection(0,true);
                binding.spEstado.setSelection(0,true);
                binding.radioFemenino.setChecked(false);
                binding.radioMasculino.setChecked(false);
                binding.swTerminosCurp.setChecked(false);
            }
        });



            binding.buttonGenerar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (binding.swTerminosCurp.isChecked()){
                        int contVocales = 0;
                        int contConsonante = 0;
                        int cuentaV = 0;
                        int cuentaC = 0;
                        String VApPat = "";
                        String CApMat = "";
                        String SCPAp= "";
                        String SCSAp= "";

                        //Apellido Paterno
                        //String primeraLApPat = binding.etApat.getText().toString().substring(0,1).toUpperCase();
                        String primeraVApPat = binding.etApat.getText().toString().toUpperCase();
                        String primeraCApMat = binding.etAmat.getText().toString().toUpperCase().substring(0,1);
                        String segundaCSApeMat = binding.etAmat.getText().toString().toUpperCase();
                        char[] arrApat = primeraVApPat.toCharArray();
                        char[] arrApmat = segundaCSApeMat.toCharArray();


                        //RECORRE EL ARREGLO DE LA PRIMERA VOCAL APELLIDO PATERNO
                            for (int i=0; i< primeraVApPat.length(); i++){
                                if(arrApat[i] == 'A' || arrApat[i] == 'E' || arrApat[i] == 'I' || arrApat[i] == 'O' || arrApat[i] == 'U'){
                                    //Si esta en la posicion 0 agrega la letra aunque sea vocal
                                    if (i==0){
                                        VApPat += arrApat[i];
                                    }else if(i>0){
                                        //agrega la vocal y agrega que ya lleva 1 vocal a la cuenta
                                        if (cuentaV==0){
                                            VApPat += arrApat[i];
                                            cuentaV = 1;
                                        }
                                    }
                                }else{
                                    //Si no es vocal es consonante y la agrega
                                    cuentaC +=1;
                                    if (i==0){
                                        VApPat += arrApat[i];
                                        cuentaC = 1;
                                    }

                                    //Agrega la segunda consonante del primer apellido
                                    if (cuentaC == 2){
                                        SCPAp += arrApat[i];
                                    }
                                }
                            }

                            //Si la cuenta de consonantes del apellido 1 no llega a dos asigna una x
                            if(cuentaC<2){
                                SCPAp = "X";
                            }

                        cuentaC=0;

                        //RECORRE EL ARREGLO DEL SEGUNDO APELLIDO
                        for (int i=0; i< segundaCSApeMat.length(); i++){
                            if(arrApmat[i] == 'A' || arrApmat[i] == 'E' || arrApmat[i] == 'I' || arrApmat[i] == 'O' || arrApmat[i] == 'U'){
                                //SI ES VOCAL NO HACE NADA
                            }else{
                                //Si no es vocal es consonante y comienza a contar
                                cuentaC +=1;
                                //Agrega la segunda consonante del primer apellido
                                if (cuentaC == 2){
                                    SCSAp += arrApmat[i];
                                }
                            }
                        }

                        //Si la cuenta del segunda consonante del seg apellido es menor a dos asigna una X
                        if(cuentaC<2){
                            SCSAp = "X";
                        }

                        //CUENTA CONSONANTES PRIMER NOMBRE
                        String SCPnom = "";
                        String nombres = binding.etNombres.getText().toString().toUpperCase();
                        char [] arrSCNombres = nombres.toCharArray();
                        cuentaC=0;

                        //RECORRE EL ARREGLO DEL SEGUNDO APELLIDO
                        for (int i=0; i< nombres.length(); i++){
                            if(arrSCNombres[i] == 'A' || arrSCNombres[i] == 'E' || arrSCNombres[i] == 'I' || arrSCNombres[i] == 'O' || arrSCNombres[i] == 'U'){
                                //SI ES VOCAL NO HACE NADA
                            }else{
                                //Si no es vocal es consonante y comienza a contar
                                cuentaC +=1;
                                //Agrega la segunda consonante del primer apellido
                                if (cuentaC == 2){
                                    SCPnom += arrSCNombres[i];
                                }
                            }
                        }

                        //Si la cuenta del segunda consonante del seg apellido es menor a dos asigna una X
                        if(cuentaC<2){
                            SCPnom = "X";
                        }


                        //Nombre
                        String primerLNom = binding.etNombres.getText().toString().substring(0,1).toUpperCase();
                        if(primerLNom.length() > 0){

                        }else{
                            primerLNom = "X";
                        }

                        //AÑO NACIMIENTO
                        String anac = binding.etAno.getText().toString().substring(2, 4);

                        //DIA NACIMIENTO
                        String dnac = binding.spDia.getSelectedItem().toString();

                        //MES NACIMIENTO
                        String mnac = binding.spMes.getSelectedItem().toString();

                        //ESTADO NACIMIENTO
                        String estado = binding.spEstado.getSelectedItem().toString().toUpperCase();
                        if(estado.equals("AGUASCALIENTES")){
                            estado = "AS";
                        } else if (estado.equals("BAJA CALIFORNIA")){
                            estado = "BC";
                        }else if (estado.equals("BAJA CALIFORNIA SUR")){
                            estado = "BS";
                        }else if (estado.equals("CAMPECHE")){
                            estado = "CC";
                        }else if (estado.equals("COAHUILA")){
                            estado = "CL";
                        }else if (estado.equals("COLIMA")){
                            estado = "CM";
                        }else if (estado.equals("CHIAPAS")){
                            estado = "CS";
                        }else if (estado.equals("CHIHUAHUA")){
                            estado = "CH";
                        }else if (estado.equals("CIUDAD DE MÉXICO")){
                            estado = "DF";
                        }else if (estado.equals("DURANGO")){
                            estado = "DG";
                        }else if (estado.equals("GUANAJUATO")){
                            estado = "GT";
                        }else if (estado.equals("GUERRERO")){
                            estado = "GR";
                        }else if (estado.equals("HIDALGO")){
                            estado = "HG";
                        }else if (estado.equals("JALISCO")){
                            estado = "JC";
                        }else if (estado.equals("ESTADO DE MÉXICO")){
                            estado = "MC";
                        }else if (estado.equals("MICHOACÁN")){
                            estado = "MN";
                        }else if (estado.equals("MORELOS")){
                            estado = "MS";
                        }else if (estado.equals("NAYARIT")){
                            estado = "NT";
                        }else if (estado.equals("NUEVO LEÓN")){
                            estado = "NL";
                        }else if (estado.equals("OAXACA")){
                            estado = "OC";
                        }else if (estado.equals("PUEBLA")){
                            estado = "PL";
                        }else if (estado.equals("QUERÉTARO")){
                            estado = "QT";
                        }else if (estado.equals("QUINTANA ROO")){
                            estado = "QR";
                        }else if (estado.equals("SAN LUIS POTOSÍ")){
                            estado = "SP";
                        }else if (estado.equals("SINALOA")){
                            estado = "SL";
                        }else if (estado.equals("SONORA")){
                            estado = "SR";
                        }else if (estado.equals("TABASCO")){
                            estado = "TC";
                        }else if (estado.equals("TAMAULIPAS")){
                            estado = "TS";
                        }else if (estado.equals("TLAXCALA")){
                            estado = "TL";
                        }else if (estado.equals("VERACRUZ")){
                            estado = "VZ";
                        }else if (estado.equals("YUCATÁN")){
                            estado = "";
                        }else if (estado.equals("ZACATECAS")){
                            estado = "ZS";
                        }


                        //GENERO
                        //RadioButtons con if para checar if checked true return data
                        String genero = "";
                        if (binding.radioMasculino.isChecked()){
                            genero = "H";
                        }else{
                            genero = "M";
                        }
                        //Hacer variables por primeraletra, primera consonante, y asi ...

                        int D1 = new Random().nextInt(10); //Número aleatorio del 0 al 9
                        int D2 = new Random().nextInt(10); //Número aleatorio del 0 al 50
                        binding.textViewCurp.setText(VApPat+primeraCApMat+primerLNom+anac+mnac+dnac+genero+estado+SCPAp+SCSAp+SCPnom+D1+D2);
                    }else{
                        binding.swTerminosCurp.setError("Acepta los TyC");

                    }


                }
            });


        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}